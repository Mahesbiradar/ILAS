// src/components/common/Loader.jsx
export default function Loader() {
  return <div className="text-center p-4 text-gray-500">Loading...</div>;
}
