export default function Transactions() {
  return <div className="text-2xl font-semibold">Transactions 💳</div>;
}
