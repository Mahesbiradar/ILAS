export default function About() {
  return (
    <div className="p-10 text-xl">
      <h1 className="font-bold text-2xl mb-4">About ILAS</h1>
      <p>Innovative Library Automation System for small community libraries.</p>
    </div>
  );
}
